<?php
namespace app\hardware\route;

use think\facade\Route;
use think\route\Rule;

Route::rule('hardwaredm','index/hardwareDataManage')->allowCrossDomain();
