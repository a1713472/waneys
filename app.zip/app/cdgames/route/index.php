<?php
namespace app\cdgames\route;

use think\facade\Route;

Route::rule('eaddscore','index/eAddMiniTaskScore')->allowCrossDomain();